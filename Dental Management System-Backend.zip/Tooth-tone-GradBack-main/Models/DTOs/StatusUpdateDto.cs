namespace DentalManagementAPI.Models.DTOs
{
    public class StatusUpdateDto
    {
        public string Status { get; set; }
    }

}