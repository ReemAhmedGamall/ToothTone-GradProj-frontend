import doctor from "../../image/doc2.png";


let all_product = [
  {
    id: 1,
    name: "Dr. Menna Mostafa",
    image: doctor,
    price: "$40",
    address: "Zahraa Madinet nasr",
    about: "Dr. Menna has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Menna has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies."
  },
  {
    id: 2,
    name: "dr. heba",
    image: doctor,
    price: "$40",
    address: "Abaas Elakad",
    about: "Dr. Heba has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Heba has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies."
  },
  {
    id: 3,
    name: "dr. salma",
    image: doctor,
    price: "$40",
    address: "Makran abeed",
    about:"Dr. Salma has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Salma has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies."
  },
  {
    id: 4,
    name: "dr. mostafa",
    image: doctor,
    price: "$40",
    address: "Mostafa El-Nahas",
    about: "Dr. Mostafa has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies. Dr. Mostafa has a strong commitment to delivering comprehensive medical care, focusing on preventive medicine, early diagnosis, and effective treatment strategies."
  }
];

export default all_product;
