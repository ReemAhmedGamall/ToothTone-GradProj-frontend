import React from 'react'

const ResPatientPayment = () => {
  return (
        <div>
            <Patientoption/>
        </div>
  )
}

export default ResPatientPayment;
