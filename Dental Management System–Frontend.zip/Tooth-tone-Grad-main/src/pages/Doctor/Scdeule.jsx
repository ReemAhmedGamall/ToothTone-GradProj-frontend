import React from 'react'
import MakeSchdeule from "../../componenet/Doctorcomponent/Schdeule/MakeSchdeule"

export const Scdeule = () => {
    return (
        <div>
            <MakeSchdeule />
        </div>
    )
}

export default Scdeule