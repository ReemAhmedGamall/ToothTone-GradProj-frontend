import React from 'react'
import DoctorSidebar from '../../componenet/Doctorcomponent/Sidebar/Sidebar'
import Showpatientdata from '../../componenet/Doctorcomponent/ShowPatientData/Showpatientdata'

export const Patient = () => {
    return (
        <div >
            <Showpatientdata />
        </div>
    )
}
export default Patient;
