import React from 'react'
import DoctorProfile from '../../componenet/Doctorcomponent/Profile/DoctorProfile'

export const Profile = () => {
    return (
        <div>
            <DoctorProfile />
        </div>
    )
}
export default Profile
