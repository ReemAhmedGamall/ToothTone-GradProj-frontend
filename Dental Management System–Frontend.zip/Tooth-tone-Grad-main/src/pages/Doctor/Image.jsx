import React from 'react'
import Imagepatient from '../../componenet/Doctorcomponent/Docs_Image/Imagepatient';
import Patientoption from '../../componenet/Doctorcomponent/ShowPatientData/Patientoption';

export const Image = () => {
  return (
    <div>
      <Patientoption />
      <Imagepatient />
    </div>
  )
}
export default Image;