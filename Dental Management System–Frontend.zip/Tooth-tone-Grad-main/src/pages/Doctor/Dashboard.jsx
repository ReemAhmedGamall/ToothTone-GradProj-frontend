import React from 'react'
import DashBoard from "../../componenet/Doctorcomponent/dashboard/DashBoardInfo"

export const Dashboard = () => {
    return (
        <div>
            <DashBoard />
        </div>
    )
}
export default Dashboard;