import React from 'react'
import Patientoption from '../../componenet/Doctorcomponent/ShowPatientData/Patientoption';
import EditprescriptionInfo from "../../componenet/Doctorcomponent/Prescription/EditPrescriptionInfo.jsx"


export const Editprescription = () => {
    return (
        <div>
            <Patientoption />
            <EditprescriptionInfo />
        </div>
    )
}
export default Editprescription;