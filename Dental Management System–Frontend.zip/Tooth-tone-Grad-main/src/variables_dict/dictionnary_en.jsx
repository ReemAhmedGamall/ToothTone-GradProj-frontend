export const __dictionnary = {
    lang: 'en-GB',
  
    mobility: 'Mobility',
    implant: 'Implant',
    implants: 'Implants',
    furcation: 'Furcation',
    bleed_on_probing: 'Bleed on probing',
    plaque: 'Plaque',
    gingival_depth: 'Gingival depth',
    average_gingival_depth: 'Average gingival depth',
    probing_depth: 'Probing depth',
    average_probing_depth: 'Average probing depth',
    start: 'Start',
    stop: 'Stop',
  
    //statistics
    statistics: 'Statistics',
    missing_teeth: 'Missing teeth',
  
    //voice control
    missing: 'missing',
    stop_recognition: 'stop',
    tooth: 'tooth'
  };